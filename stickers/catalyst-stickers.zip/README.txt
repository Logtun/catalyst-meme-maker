Catalyst stickers (fan-made by @iamlogtun, not official).
whatsapp-512-webp: 512x512 WebP, transparent, each under 100 KB.
discord-320-png: 320x320 PNG.
Make your own: https://catalyst-memes.sites.tab.bot/#stickers
